
import socket

class FileSend:
    def __init__(self, name):
        self.f = open(name, "rb")
    def send(self, s):
        _ = self.f.read(1024)
        while _:
            s.send(_)
            s.recv(1024)
            _ = self.f.read(1024)
        s.send(b'done')


if __name__ == '__main__':
    s = socket.socket()
    s.connect(("127.0.0.1", 8080))
    s.send(b"Hello")
    data = s.recv(1024)
    FileSend("image1.png").send(s)
    print(data)
    s.close()