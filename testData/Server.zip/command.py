

class Command:
    def __init__(self):
        pass