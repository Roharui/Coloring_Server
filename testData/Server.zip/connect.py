
import threading
import socket
from time import sleep
import file
import command

conn_num = 0

class Connection(threading.Thread):
    def __init__(self, connect, addr):
        threading.Thread.__init__(self)

        self.connect = connect
        self.addr = addr
        self.f = file.File(self.connect)
        self.command = command.Command()

    def run(self):
        try:
            print("connect at : {0}".format(self.addr))
            conn = self.connect

            cmd = conn.recv(1024).decode()
            #커맨드

            conn.send(b'sending success')
            self.f.recvFile()
        finally:
            conn.close()
