
import os
import socket
import time

class File:
    base_path = "./data/"
    def __init__(self, conn):

        str_time = time.strftime('%Y-%m-%d-%H-%M-%S',time.localtime(time.time()))
        self.name = self.base_path + str_time + ".png"
        self.s = conn

    def recvFile(self):
        with open(self.name, "wb") as f:
            while True:
                tmp = self.s.recv(1024)
                if tmp == b'done':
                    break
                f.write(tmp)
                self.s.send(b" ")

    def getName(self):
        return self.name

    def delFile(self):
        os.remove(self.name)
