
import threading, socket
import connect
import sys

class Server(threading.Thread):
    def __init__(self, ip, port):
        threading.Thread.__init__(self)

        self.s = socket.socket()
        self.s.bind((ip, port))
        self.s.listen(1)

        print("Server is starting at : {0}:{1}".format(ip, port))

    def run(self):
        while True:
            conn, addr = self.s.accept()
            connect.Connection(conn, addr).start()

if __name__ == '__main__':
    ip = sys.argv[1]
    port = int(sys.argv[2])

    s = Server(ip, port)
    s.start()